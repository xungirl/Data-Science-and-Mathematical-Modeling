
import xlwings as xw # 载入
import numpy as np # 载入
from matplotlib import pyplot as plt
from wangge import wang
from date import dateing
sheet_two_lie=15
def f_fit(x,y_fit):
    a,b=y_fit.tolist()
    return a*x+b
def pic(xx,yy,Xlabel,Ylabel,shi,wei1,wei2,wei3):
    plt.subplot(wei1,wei2,wei3)
    wei=wei1+wei2+wei3
    #print(wei)
    #wang(0,xx+10,0,yy+10,wei)
    plt.grid(True)
    plt.scatter(xx,yy,c='g',label='before_fitting')#散点图
    plt.plot(xx,yy,'b--',label='fitting')
    #plt.title(shi)
    plt.xticks(range(1,sheet_two_lie),labels=Xlabel)
    plt.xticks(rotation=270)
    plt.ylabel(Ylabel)
    #plt.legend()#显示标签

def pic1(xx,yy,Xlabel,Ylabel,shi,wei1,wei2,wei3):
    plt.subplot(wei1,wei2,wei3)
    wei=wei1+wei2+wei3
    #print(wei)
    #wang(0,xx+10,0,yy+10,wei)
    plt.grid(True)
    plt.scatter(xx,yy,c='r',label='before_fitting')#散点图
    plt.plot(xx,yy,'y--',label='fitting')
    #plt.title(shi)
    plt.xticks(range(1,sheet_two_lie),labels=Xlabel)
    plt.xticks(rotation=270)
    plt.ylabel(Ylabel)

a=dateing(2,59,1,5,'data.xls',0)#第一个sheet
A=[]
hang_num=(9-1)
b=dateing(2,hang_num+1,1,sheet_two_lie,'new_date.xls',1)#第二个sheet 
bb=dateing(2,hang_num+1,1,1,'new_date.xls',1)#第二个sheet    
yuu=0
ss1='高钾'
ss2='铅钡'
ss3='风化'
ss4='无风化'
ss777=''
ss888=[]
for i in range(1,59):
    ss777=''
    ss777+=a[i+2*58-1]
    ss777+='-'
    ss777+=a[i+4*58-1]
    ss888.append(ss777)
    A.append([])
    A[yuu].append(a[i-1])
    A[yuu].append(a[i+58-1])
    A[yuu].append(a[i+2*58-1])
    A[yuu].append(a[i+3*58-1])
    A[yuu].append(a[i+4*58-1])
    yuu+=1
    pass
print(A)
B=[]
yuu=0
for i in range(1,hang_num+1):
    B.append([])
    sum=0
    for j in range(1,sheet_two_lie):
        if b[i+j*hang_num-1]!=None:
            B[yuu].append(b[i+j*hang_num-1])
        else : 
            B[yuu].append(0)
    #for j in range(0,len(B[yuu])):
    #    B[yuu][j]=100/sum*B[yuu][j]
    yuu+=1

id=''
f=np.linspace(1,sheet_two_lie-1,sheet_two_lie-1)

X_labels=['(SiO2)','(Na2O)','(K2O)','(CaO)','(MgO)','(Al2O3)','(Fe2O3)','(CuO)','(PbO)','(BaO)','(P2O5)','(SrO)','(SnO2)','(SO2)'
]
biao1=[]
biao2=[]
biao3=[]
biao4=[]
x1=np.array(f)
sum=0
for i in range(0,hang_num):
    y1=np.array(B[i])
    if B[i][8]==0:
        if bb[i]=='无风化':
            pic1(x1,y1,X_labels,'U',(ss1+'-'+ss3),1,2,1)
        else:
            pic1(x1,y1,X_labels,'U',(ss1+'-'+ss3),1,2,2)
    else:
        if bb[i]=='无风化':
            pic(x1,y1,X_labels,'U',(ss1+'-'+ss3),1,2,1)
        else:
            pic(x1,y1,X_labels,'U',(ss1+'-'+ss3),1,2,2)


plt.show()