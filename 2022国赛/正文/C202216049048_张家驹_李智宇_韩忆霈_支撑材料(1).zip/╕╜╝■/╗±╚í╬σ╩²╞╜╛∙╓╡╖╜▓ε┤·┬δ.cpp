#include<bits/stdc++.h>
using namespace std;
double a[100][100];
double aa[100],ping[100][100],fang[100][100];
double aaa[10][5][15];
int b[100];
string str[10]={"","�߼�-�޷绯","Ǧ��-�绯","�߼�-�绯","Ǧ��-�޷绯"};
int main()
{
	freopen("yuce.in","r",stdin);
	for(int i=1;i<=67;i++)
	{
		for(int j=1;j<=14;j++)
			scanf("%lf",&a[i][j]);
		scanf("%d",&b[i]);
	}
	cout<<1<<endl;
	for(int i=1;i<=4;i++)
	{
		for(int z=1;z<=14;z++)
		{
			int yu=0;
			for(int j=1;j<=67;j++)
			{
				if(b[j]==i)
				{
					aa[++yu]=a[j][z];
				}
			}
			sort(aa+1,aa+yu+1);
			aaa[1][i][z]=aa[1];
			aaa[2][i][z]=aa[(int)(yu/4.0+0.5)];
			aaa[3][i][z]=aa[(int)(yu/2.0+0.5)];
			aaa[4][i][z]=aa[(int)((double)(yu/4.0+0.5)*3.0)];
			aaa[5][i][z]=aa[yu];
			for(int j=1;j<=yu;j++)
				ping[i][z]+=aa[j];
			ping[i][z]/=yu;
			for(int j=1;j<=yu;j++)
				fang[i][z]+=(aa[j]-ping[i][z])*(aa[j]-ping[i][z]);
			fang[i][z]/=yu;
			
		}
	}
	
	for(int i=1;i<=4;i++)
	{
		cout<<str[i]<<":\n";
		for(int j=1;j<=5;j++)
		{
			for(int z=1;z<=14;z++)cout<<aaa[j][i][z]<<' ';
			cout<<endl;
		}
		for(int z=1;z<=14;z++)cout<<ping[i][z]<<' ';
		cout<<endl;
		for(int z=1;z<=14;z++)cout<<fang[i][z]<<' ';
		cout<<endl;
	}
	return 0;
 } 
