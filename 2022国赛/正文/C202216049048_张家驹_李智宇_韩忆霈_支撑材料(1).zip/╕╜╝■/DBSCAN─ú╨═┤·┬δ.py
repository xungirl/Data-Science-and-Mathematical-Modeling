import numpy as np
import pandas as pd
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import time

read_df = pd.read_csv('second_data.csv',encoding='GB2312')

target = read_df.iloc[:, -2]
data = read_df.iloc[:, 1:-2]

k = 3
n = data.shape[0]

def TOGETMIIIIIIIIIIIIAS(p_B, D_B_I_B_S, E_B_P_B_S):
    safdegegds = np.where(D_B_I_B_S[:, p_B] <= E_B_P_B_S ** 2)[0]
    return safdegegds

D_B_I_B_S = np.zeros([n, n])
for i in range(n - 1):
    for j in range(i + 1, n):
        D_B_I_B_S[j][i] = ((data.iloc[j] - data.iloc[i]) ** 2).sum()
    print("dddd：{}/{}".format(i + 1, n))
gdsfsdfsfhh = np.triu_indices(n, 0)
D_B_I_B_S[gdsfsdfsfhh] = D_B_I_B_S.T[gdsfsdfsfhh]
print("dddd：{}/{}".format(n, n))
def growCluster(D_B_I_B_S, p_B_r_B_e_p_B_o_B_i_B_n_B_t, L_B_A_B_B_B_E_B_L_B_S, p_B, E_B_P_B_S, MinPts):
    if L_B_A_B_B_B_E_B_L_B_S[p_B] == -1:
        return L_B_A_B_B_B_E_B_L_B_S, p_B_r_B_e_p_B_o_B_i_B_n_B_t
    asfsdgfdhgf = TOGETMIIIIIIIIIIIIAS(p_B, D_B_I_B_S, E_B_P_B_S)
    
    # 遍历p的密度直达点
    i = 0
    while i < len(asfsdgfdhgf):
        lslslslssls = asfsdgfdhgf[i]
        lslslslsslsasfsdgfdhgf = TOGETMIIIIIIIIIIIIAS(lslslslssls, D_B_I_B_S, E_B_P_B_S)
        if len(lslslslsslsasfsdgfdhgf) >= MinPts:
            Setdiff1d = np.setdiff1d(lslslslsslsasfsdgfdhgf, asfsdgfdhgf) 
            asfsdgfdhgf = np.hstack((asfsdgfdhgf, Setdiff1d))
        i += 1
    p_B_r_B_e_p_B_o_B_i_B_n_B_t[asfsdgfdhgf] = p_B_r_B_e_p_B_o_B_i_B_n_B_t[p_B]
    L_B_A_B_B_B_E_B_L_B_S[asfsdgfdhgf] = -1
    return L_B_A_B_B_B_E_B_L_B_S, p_B_r_B_e_p_B_o_B_i_B_n_B_t

def lslslslsslssaaaaa(n, k ,D_B_I_B_S, E_B_P_B_S, MinPts, jjjja=2):
    jjjjasasaasd = int(round(time.time() * 1000000))

    p = 0
    L_B_A_B_B_B_E_B_L_B_S = np.zeros(n) 
    p_B_r_B_e_p_B_o_B_i_B_n_B_t = np.arange(n)
    
    if jjjja == 2:
        pass

    while p < n:
        L_B_A_B_B_B_E_B_L_B_S, p_B_r_B_e_p_B_o_B_i_B_n_B_t = growCluster(D_B_I_B_S, p_B_r_B_e_p_B_o_B_i_B_n_B_t, L_B_A_B_B_B_E_B_L_B_S, p, E_B_P_B_S, MinPts)
        c_num = len(np.unique(p_B_r_B_e_p_B_o_B_i_B_n_B_t))
        if jjjja == 2:
            pass
        if c_num <= k:
            break
        p += 1

    if jjjja == 2:
        pass

    jjjjasa = int(round(time.time() * 1000000))

    if jjjja == 1:
        return 0, jjjjasa - jjjjasasaasd
    elif jjjja == 2:
        return p_B_r_B_e_p_B_o_B_i_B_n_B_t


p_B_r_B_e_p_B_o_B_i_B_n_B_t = lslslslsslssaaaaa(n=n, k=k, D_B_I_B_S=D_B_I_B_S, E_B_P_B_S=46.5, MinPts=60)


# 可视化
cc=['r','b','g','y']
# 红是高钾-无风化
# 蓝是铅钡-风化
# 绿是高钾-风化
# 黄是铅钡-无风化

#红是风化
#蓝是无风化

#红是高钾
#蓝是铅钡
#TSNE降维
The_point_location=TSNE(n_components=2,random_state=34).fit_transform(data)
#(((int)(time.time()))%100)
xxxx = np.array(The_point_location[:,0])
yyyy = np.array(The_point_location[:,1])
#y = np.array(data.iloc[:, 1])
print(target)
ccc=[]
ddd=[]
maxx=0
for i in target:
    ccc.append(cc[i-1])


def DROWING(wei1,wei2,wei3,colouring):
    plt.subplot(wei1,wei2,wei3)
    plt.scatter(xxxx, yyyy, c=colouring)
DROWING(2,1,1,ccc)
DROWING(2,1,2,p_B_r_B_e_p_B_o_B_i_B_n_B_t)

plt.show()
DDict={}
yuu=0
GG=[]
for i in range(0,len(p_B_r_B_e_p_B_o_B_i_B_n_B_t)):
    if DDict.get(p_B_r_B_e_p_B_o_B_i_B_n_B_t[i])==None:
        yuu+=1
        DDict[p_B_r_B_e_p_B_o_B_i_B_n_B_t[i]]=yuu
        GG.append(yuu)
    else:
        GG.append(DDict[p_B_r_B_e_p_B_o_B_i_B_n_B_t[i]])
print(GG)
#The_point_location=TSNE(n_components=3,random_state=35).fit_transform(data)
#xxx=np.array(The_point_location[:,0])
#yyy=np.array(The_point_location[:,1])
#zzz=np.array(The_point_location[:,2])

#fig=plt.figure()
#ax=Axes3D(fig)
#ax.scatter(xxx,yyy,zzz,c=p_B_r_B_e_p_B_o_B_i_B_n_B_t)


from sklearn.metrics import calinski_harabasz_score
calinski_harabaz_BBBBBB = p_B_r_B_e_p_B_o_B_i_B_n_B_t
print('当前聚类分析的calinski_harabaz指数为:%f'%(calinski_harabasz_score(data,calinski_harabaz_BBBBBB)))

plt.show()
