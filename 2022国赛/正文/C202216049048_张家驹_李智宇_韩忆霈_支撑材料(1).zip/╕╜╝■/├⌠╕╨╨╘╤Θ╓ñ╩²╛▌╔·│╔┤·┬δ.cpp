#include<bits/stdc++.h>
using namespace std;
double aa[1010][1010];
double Xi[10]={0.87,0.91,0.97,1.03,1.07,1.1};
int main()
{
	srand(time(0));
	freopen("a.in","r",stdin);
	for(int i=1;i<=32;i++)
	{
		for(int j=1;j<=14;j++)
			cin>>aa[i][j];
	}
	for(int i=1;i<=32;i++)
	{
		double sum=0;
		for(int j=2;j<=14;j++)
		{
			aa[i][j]*=Xi[(rand()%6)];
			sum+=aa[i][j];
		}
		aa[i][1]=100-sum;
	}
	for(int i=1;i<=32;i++)
	{
		for(int j=1;j<14;j++)
			cout<<aa[i][j]<<',';
			cout<<aa[i][14]<<endl;
	}
	return 0;
}
